const grid = new gridjs.Grid({
    columns: [
      {
        id: 'myCheckbox',
        name: 'Select',
        plugin: {
          // install the RowSelection plugin
          component: gridjs.plugins.selection.RowSelection,
        }
      },
      { id: 'name', name: 'Name' },
      { id: 'age', name: 'Age' },
      { id: 'address', name: 'Address', sort: false },
      { id: 'phone', name: 'Phone Number', sort: false },
      { id: 'email', name: 'Email' },
    ],
    server: {
      url: '/api/data',
      then: results => results.data,
    },
    search: {
      selector: (cell, rowIndex, cellIndex) => [0, 1, 4].includes(cellIndex) ? cell : null,
    },
    sort: true,
    pagination: true,
  }).render(document.getElementById('table'));

  // Add event handler to prep
  prep.addEventListener ("click", function() {
    var selections = grid.config.store.state.rowSelection.rowIds
    console.log(selections)
    console.log('selected rows:', grid.config.store.state);

    var captureSelectionsPrep = []
    for (let i = 0; i < grid.config.store.state.data.length; i++) {
      if (grid.config.store.state.data._rows[i]._cells[0].data == true) {
        captureSelectionsPrep.push(grid.config.store.state.data._rows[i]._cells[1].data)
      }
    }

    // post to api 
    fetch('https://reqbin.com/echo/post/json', {
          method: 'POST',
          headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json'
          },
          body: JSON.stringify({ "id": 78912 })
      })
        .then(response => response.json())
        .then(response => console.log(JSON.stringify(response)))
        
    alert("Running prep on: " + captureSelectionsPrep)
  
  });

  // Add event handler to Finalise
  finalise.addEventListener ("click", function() {
    var selections = grid.config.store.state.rowSelection.rowIds
    console.log(selections)
    console.log('selected rows:', grid.config.store.state);

    var captureSelections = []
    for (let i = 0; i < grid.config.store.state.data.length; i++) {
      if (grid.config.store.state.data._rows[i]._cells[0].data == true) {
        captureSelections.push(grid.config.store.state.data._rows[i]._cells[1].data)
      }
    }

    // post to api 
    fetch('https://reqbin.com/echo/post/json', {
          method: 'POST',
          headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json'
          },
          body: JSON.stringify({ "id": 78912 })
      })
        .then(response => response.json())
        .then(response => console.log(JSON.stringify(response)))

    // raise alert for testing
    alert("Running finalise on: " + captureSelections)

  });