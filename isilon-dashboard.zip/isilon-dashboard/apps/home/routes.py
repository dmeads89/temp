# -*- encoding: utf-8 -*-
"""
Copyright (c) 2019 - present AppSeed.us
"""

from apps.home import blueprint
from flask import render_template, request
from jinja2 import TemplateNotFound
from apps.source import datasource
import time
from datetime import datetime


@blueprint.route('/')
def index():

    current_time = datetime.now()
    date_time = current_time.strftime("%m/%d/%Y, %H:%M:%S")

    # Detect the current page
    segment = get_segment(request)

    ## retrieve all the data in one go
    data = datasource.retrieve_cluster_data()

    ## extract cluster list needs by all views in the sidebar
    clusters = data.keys()
    failed_power_supplies, failed_disks = datasource.list_unhealthy_hardware(data)

    unresolved_critical_events, unresolved_warning_events = datasource.unresolved_events(data)

    failed_jobs = datasource.failed_jobs(data)

    return render_template(
                "home/dashboard.html",
                segment=segment, 
                count_failed_disks=len(failed_disks),
                failed_disks=failed_disks, 
                count_powersupplies_issues=len(failed_power_supplies),
                powersupply_issues=failed_power_supplies,
                count_unresolved_critical=len(unresolved_critical_events),
                unresolved_critical_events=unresolved_critical_events,
                count_unresolved_warning=len(unresolved_warning_events),
                unresolved_warning_events=unresolved_warning_events,
                failed_jobs=failed_jobs,
                clusters=clusters, 
                data=data, 
                date_time=date_time)


@blueprint.route('/<template>')
def route_template(template, c=None):

    current_time = datetime.now()
    date_time = current_time.strftime("%m/%d/%Y, %H:%M:%S")

    try:

        if not template.endswith('.html'):
            template += '.html'

        # Detect the current page
        segment = get_segment(request)

        ## retrieve all the data in one go
        data = datasource.retrieve_cluster_data()

        ## extract cluster list needs by all views in the sidebar
        clusters = data.keys()

        if template == 'hardware.html':
            c = request.args.get('c')
            return render_template("home/hardware.html",segment=segment, clusters=clusters, data=data, hardware=data[c]['hardware']['nodes'], date_time=date_time)
        elif template == 'jobreports.html':
            c = request.args.get('c')
            return render_template("home/jobreports.html",segment=segment, clusters=clusters, data=data, jobs=data[c]['job_summary'], date_time=date_time)
        elif template == 'overview.html':
            cluster_total = len(clusters)
            return render_template(
                "home/overview.html",
                segment=segment, 
                cluster_total=cluster_total, 
                clusters=clusters, 
                data=data, 
                date_time=date_time)
        elif template == 'dashboard.html':
            failed_power_supplies, failed_disks = datasource.list_unhealthy_hardware(data)

            unresolved_critical_events, unresolved_warning_events = datasource.unresolved_events(data)

            failed_jobs = datasource.failed_jobs(data)

            return render_template(
                "home/dashboard.html",
                segment=segment, 
                count_failed_disks=len(failed_disks),
                failed_disks=failed_disks, 
                count_powersupplies_issues=len(failed_power_supplies),
                powersupply_issues=failed_power_supplies,
                count_unresolved_critical=len(unresolved_critical_events),
                unresolved_critical_events=unresolved_critical_events,
                count_unresolved_warning=len(unresolved_warning_events),
                unresolved_warning_events=unresolved_warning_events,
                failed_jobs=failed_jobs,
                clusters=clusters, 
                data=data, 
                date_time=date_time)
        else:
            return render_template("home/" + template, segment=segment, clusters=clusters, data=data, date_time=date_time)

    except TemplateNotFound:
        return render_template('home/page-404.html'), 404

    except Exception as e:
        print(e)
        return render_template('home/page-500.html'), 500


# Helper - Extract current page name from request
def get_segment(request):

    try:

        segment = request.path.split('/')[-1]

        if segment == '':
            segment = 'dashboard'

        return segment

    except:
        return None
