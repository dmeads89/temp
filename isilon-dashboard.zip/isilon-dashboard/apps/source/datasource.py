import json

def retrieve_cluster_data():

    with open(r"C:\HomeLab\flask-dash\isilon-dashboard\apps\source\testdata.json", 'r') as f:
        cluster_data = json.load(f)

    return cluster_data

def list_unhealthy_hardware(cluster_data):

    power_supplies = []
    disks = []
    nodes = []

    for key,cluster in cluster_data.items():
        ## collect unhealthy disks
        if cluster['hardware']['unhealthy_disks'] != []:
            disks = disks + cluster['hardware']['unhealthy_disks']

        for node in cluster['hardware']['nodes']:
            if node['power'] != "Power Supplies OK":
                power_supplies.append(
                    {
                        "cluster": key,
                        "lnn": node['lnn'],
                        "status": node['power']
                    }
                )

    return power_supplies, disks

def unresolved_events(cluster_data):

    unresolved_warnings = []
    unresolved_critical = []

    for key, value in cluster_data.items():
        for event in value['events']:
            ## add cluster to make data easier to use
            event['cluster'] = key

            ## add to relevant list
            if event['severity'] == 'warning':
                unresolved_warnings.append(event)
            elif event['severity'] == 'critical':
                unresolved_critical.append(event)
    
    return unresolved_critical, unresolved_warnings

def failed_jobs(cluster_data):

    failed_jobs = []

    for key, value in cluster_data.items():
        for job in value['job_summary']:
            if job['status'] == 'Failed':
                job['cluster'] = key
                failed_jobs.append(job)
    
    return failed_jobs

## test only
if __name__ == "__main__":

    cluster_data = retrieve_cluster_data()

    # list_failed_disks(cluster_data)

    # list_failed_powersupplies(cluster_data)

    #unresolved_events(cluster_data)

    failed_jobs(cluster_data)


