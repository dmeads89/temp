## TODO

Data to add:
- node percentage
- gather size
- node status
- job type to running job
- cluster to failed disks
- count of disks per cluster
- share information from storage-ownership
- pool size 
- provisioned totals from storage-ownership
- add node status to node output
- treedelete history
- add correct collect time rather that time.now()
- Add job id to job summary

General
- Add search bar within page - perhaps a bit too far
- change icons / even try without icon perhaps

Gathers
- Add size to the gather page, NEEDS EXTRA DATA

Running Job
- add job type, NEEDS EXTRA DATA

Node details
- Node percentage used, NEEDS EXTRA DATA
- Fans, NEEDS EXTRA DATA
- Node up or down, NEEDS EXTRA DATA

Overview
- Collect disk totals, NEEDS EXTRA DATA
- Collect share information, NEEDS EXTRA DATA


## New features

Connection count (New Dashboard)
- Connections in bar chat per cluster

TreeDelete History (New Dashboard)
- Add Treeldete history, single table all clusters

Zone details (New Dashboard)
- zones per cluster including rfc2307 settings

Network details (New Dashboard)
- pools per cluster

Protocols details per cluster per zone (New Dashboard)
- nfs, smb, nfs, hdfs what is enabled

Configured auth roles (New Dashboard)



