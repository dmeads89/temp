from flask import Flask, redirect, url_for, render_template, request

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/<platform>/pr/<pr_number>")
def commit_status(platform, pr_number):
    mylist = [
        "reason 1",
        "reason 2",
        "reason 3"
    ]
    return render_template(f"{platform}/pr.html", reasons=mylist, pr=pr_number)

@app.route("/isilon/main")
def isilon_main():
    return render_template(f"isilon/main.html")

@app.route("/isilon/cluster_detail")
def isilon_cluster_detail():
    return render_template(f"isilon/cluster_detail.html")

@app.route("/isilon/table")
def isilon_table():
    return render_template(f"isilon/isilon_table.html")

@app.route('/api/data2')
def data2():
    results = [
        {
            "id": 1,
            "title": "My title",
            "description": "Super descriptive",
            "price": "$1"
        },
        {
            "id": 2,
            "title": "Boring",
            "description": "nonsense",
            "price": "$1"
        },
        {
            "id": 3,
            "title": "Exciting",
            "description": "Cheap",
            "price": "$10"
        }
    ]
    return {'data': results}

if __name__ == "__main__":
    app.run(debug=True)