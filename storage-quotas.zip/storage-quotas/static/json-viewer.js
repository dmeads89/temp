// Function to hide the Spinner
function hideSpinner() {
    document.getElementById('spinner')
            .style.display = 'none';
} 

// get platform from the script tag
var script_tag = document.getElementById('json-viewer-id');
var platform = script_tag.getAttribute("platform");
var custom_url = "https://dummyjson.com/" + platform

var obj;
var options = {
    objectNodesLimit: 100, // how many properties of an object should be shows before it gets paginatated with a pagination size of 50
    arrayNodesLimit: 100, // same as objectNodesLimit, but with array elements
    labelAsPath: false // if true the label for every node will show the full path to the element
  }
fetch(custom_url)
  .then(res => res.json())
  .then(data => {
    obj = data;
  })
  .then(() => {
    BigJsonViewerDom.fromData(JSON.stringify(obj), options).then(viewer => {
    const node = viewer.getRootElement();
    document.body.appendChild(node);

  });
}).then(() => {
    hideSpinner();
});


